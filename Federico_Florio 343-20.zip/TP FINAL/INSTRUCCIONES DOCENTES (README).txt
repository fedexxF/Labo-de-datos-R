Me parecio mas prolijo dejar indicacciones en un txt 

Federico Florio 343/20

TEMA 16
Corriente en chorro en capas bajas
(LLJ)

Para la presentacion voy a usar los siguientes archivos

Presentacion:
1)"Federico_Florio 343-20 Presentacion_Rscript"                   (.R)
2)"Federico Florio 343-20 Presentacion"                           (pdf)
3)"Federico_Florio_Prueba_Optimizacion1.Rprofvits"                (.RPROFVIS)
4)"Federico_Florio_Prueba_Optimizacion2.Rprofvits"                (.RPROFVIS)
5)"Federico_Florio_Prueba_Optimizacion3.Rprofvits"                (.RPROFVIS)


#El siguiente archivo NO forma parte de la presentacion oral PERO
si es el script que entrego como TP final

Correccion del trabajo:
1)"Federico_Florio 343-20 Rscript"   (.R)


#Contiene dos carpetas de "datos" y "salidas"

Hago esa distincion debido a que el archivo que voy a presentar en la exposicion oral
Tiene distintos "extras" para facilitar la explicacion del codigo 